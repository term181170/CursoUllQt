#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    //Create central widget and set main layout
    wgtMain_ = new QWidget(this);
    lytMain_ = new QGridLayout(wgtMain_);
    wgtMain_->setLayout(lytMain_);
    setCentralWidget(wgtMain_);

    //Initialize widgets
    mediaPlayer_  = new QMediaPlayer(this);
    playerSlider_ = new QSlider(Qt::Horizontal, this);
    videoWidget_  = new QVideoWidget(this);
    volumeSlider_ = new QSlider(Qt::Horizontal, this);
    btnOpen_      = new QToolButton(this);
    btnPlay_      = new QToolButton(this);
    btnPause_     = new QToolButton(this);
    btnStop_      = new QToolButton(this);

    //Setup widwgets
    videoWidget_->setMinimumSize(400, 400);
    mediaPlayer_->setVideoOutput(videoWidget_);
    mediaPlayer_->setVolume(100);
    videoWidget_->setAspectRatioMode(Qt::KeepAspectRatio);
    volumeSlider_->setRange(0, 100);
    volumeSlider_->setSliderPosition(100);

    //Populate grid layout
    lytMain_->addWidget(videoWidget_,  0, 0, 1, 5);
    lytMain_->addWidget(playerSlider_, 1, 0, 1, 5);
    lytMain_->addWidget(btnOpen_,      2, 0, 1, 1);
    lytMain_->addWidget(btnPlay_,      2, 1, 1, 1);
    lytMain_->addWidget(btnPause_,     2, 2, 1, 1);
    lytMain_->addWidget(btnStop_,      2, 3, 1, 1);
    lytMain_->addWidget(volumeSlider_, 2, 4, 1, 1);

    //Buttons icons
    btnOpen_->setIcon(QIcon(QPixmap(":/icons/resources/eject.png")));
    btnPause_->setIcon(QIcon(QPixmap(":/icons/resources/pause.png")));
    btnPlay_->setIcon(QIcon(QPixmap(":/icons/resources/play.png")));
    btnStop_->setIcon(QIcon(QPixmap(":/icons/resources/stop.png")));

    //Inicializamos los menús
    mainMenu_ = new QMenuBar(this);

    mnuArchivo_ = new QMenu(tr("&Archivo"), this);
    mainMenu_->addMenu(mnuArchivo_);
    actArchivoAbrir_ = new QAction(tr("&Abrir"), this);
    actArchivoAbrir_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_O));
    mnuArchivo_->addAction(actArchivoAbrir_);
    actAbrirRemoto_ = new QAction(tr("Abrir remoto"), this);
    mnuArchivo_->addAction(actAbrirRemoto_);

    mnuRecientes_ = new QMenu(tr("&Recientes"), this);
    mnuArchivo_->addMenu(mnuRecientes_);

    actAbrirLista_ = new QAction(tr("Abrir lista..."), this);
    mnuArchivo_->addAction(actAbrirLista_);

    settings = new QSettings("CursoQt", "Reproductor");
    recientes = settings->value("recientes").toStringList();
    createMenuRecientes();

    mnuVer_ = new QMenu(tr("&Ver"), this);
    mainMenu_->addMenu(mnuVer_);
    actFullScreen_ = new QAction(tr("Pantalla completa"), this);
    actFullScreen_->setShortcut(QKeySequence(Qt::CTRL + Qt::ALT + Qt::Key_F));
    mnuVer_->addAction(actFullScreen_);

    actRestore_ = new QAction(tr("Restaurar tamaño"), this);
    mnuVer_->addAction(actRestore_);


    mnuHelp_ = new QMenu(tr("&Ayuda"), this);
    mainMenu_->addMenu(mnuHelp_);
    actAbout_ = new QAction(tr("&Acerca de"));
    mnuHelp_->addAction(actAbout_);


    //Connections
    connect(btnOpen_,      SIGNAL(pressed()),               this,         SLOT(onOpen()));
    connect(btnPlay_,      SIGNAL(pressed()),               mediaPlayer_, SLOT(play()));
    connect(btnPause_,     SIGNAL(pressed()),               mediaPlayer_, SLOT(pause()));
    connect(btnStop_,      SIGNAL(pressed()),               mediaPlayer_, SLOT(stop()));
    connect(playerSlider_, SIGNAL(sliderReleased()),        this,         SLOT(onSeek()));
    connect(mediaPlayer_,  SIGNAL(durationChanged(qint64)), this,         SLOT(onDurationChanged(qint64)));
    connect(mediaPlayer_,  SIGNAL(positionChanged(qint64)), this,         SLOT(onPositionChanged(qint64)));
    connect(volumeSlider_, SIGNAL(sliderMoved(int)),        this,         SLOT(onVolumeChanged(int)));

    connect(actArchivoAbrir_, SIGNAL(triggered()), this, SLOT(onOpen()));
    connect(actAbout_, SIGNAL(triggered()), this, SLOT(onAbout()));
    connect(actFullScreen_, SIGNAL(triggered()), this, SLOT(onFullScreen()));
    connect(actRestore_, SIGNAL(triggered()), this, SLOT(onRestoreSize()));
    connect(actAbrirRemoto_, SIGNAL(triggered()), this, SLOT(onOpenRemote()));
    connect(actAbrirLista_, SIGNAL(triggered()), this, SLOT(onAbrirLista()));

    setUnifiedTitleAndToolBarOnMac(true);

    QDockWidget *dockMetaData = new QDockWidget(tr("Metadatos"), this);
    dockMetaData->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
    dockMetaData->setVisible(false);
    metaDataList = new QListWidget(dockMetaData);
    mnuVer_->addAction(dockMetaData->toggleViewAction());
    addDockWidget(Qt::RightDockWidgetArea, dockMetaData);
    dockMetaData->setWidget(metaDataList);

    dockList = new QDockWidget(tr("Lista de reproducción"), this);
    dockList->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
    dockList->setVisible(false);
    playList = new QListWidget(dockList);
    addDockWidget(Qt::RightDockWidgetArea, dockList);
    dockList->setWidget(playList);
}

MainWindow::~MainWindow()
{

}

void MainWindow::createMenuRecientes()
{
    // Limpiamos los menús recientes antes de volverlos a añadir
    mnuRecientes_->clear();
    for (int i = 0; i < recientes.size(); ++i) {
        QAction* action = new QAction(recientes.at(i).toLocal8Bit().constData(), this);
        action->setData(i);
        connect(action, SIGNAL(triggered(bool)), this, SLOT(onOpenReciente()));
        mnuRecientes_->addAction(action);
    }
}

void MainWindow::onOpenReciente()
{
    QAction *action = qobject_cast<QAction *>(QObject::sender());
    QString fileName = recientes.at(action->data().toInt());
    QFileInfo fi(fileName);
    QString ext = fi.suffix();

    if ((ext == "m3u") || (ext == "pls"))
        abrirLista(fileName);
     else
        abrirFichero(fileName);
}

void MainWindow::addToRecientes(QString fileName)
{
    int pos = recientes.indexOf(fileName);
    if ( pos != -1) {
        // El elemento ya está en recientes. Lo quitamos y lo ponemos el primero ( como el usado más recientemente)
        recientes.removeAt(pos);
    }
    recientes.insert(0, fileName);
}

void MainWindow::showMetaData()
{
    if (mediaPlayer_->isMetaDataAvailable()) {
        QStringList availableMetaData = mediaPlayer_->availableMetaData();
        for (int i = 0; i<availableMetaData.size(); ++i) {
            metaDataList->addItem(availableMetaData.at(i));
        }
    }
}

void MainWindow::abrirFichero(QString fileName)
{
    mediaPlayer_->setMedia(QUrl::fromLocalFile(fileName));
    addToRecientes(fileName);
    createMenuRecientes();
    showMetaData();
    mediaPlayer_->play();
}

void MainWindow::onOpen()
{
    //Show file open dialog
    QString fileName = QFileDialog::getOpenFileName(this,
                                            tr("Abrir archivo"));
    if (fileName != "") {
        abrirFichero(fileName);
    }
}


void MainWindow::abrirLista(QString fileName)
{
    QMediaPlaylist* lista = new QMediaPlaylist;
    lista->load(QUrl::fromLocalFile(fileName));
    mediaPlayer_->setPlaylist(lista);
    addToRecientes(fileName);
    createMenuRecientes();
    showMetaData();
    qDebug() << lista->mediaCount();
    mediaPlayer_->play();
}

void MainWindow::onAbrirLista()
{
    //Show file open dialog
    QString fileName = QFileDialog::getOpenFileName(this,
                                            tr("Abrir archivo"),
                                            QDir::home().dirName(),
                                            tr("Listas de ficheros (*.m3u *.pls)"));
    if (fileName != "") {
        abrirLista(fileName);
    }
}

void MainWindow::onSeek()
{
    mediaPlayer_->setPosition(playerSlider_->sliderPosition());
}

void MainWindow::onDurationChanged(qint64 duration)
{
    playerSlider_->setRange(0, duration);
}

void MainWindow::onPositionChanged(qint64 position)
{
    playerSlider_->setSliderPosition(position);
}

void MainWindow::onVolumeChanged(int volume)
{
    mediaPlayer_->setVolume(volume);
}

void MainWindow::onAbout()
{
    QMessageBox msgBox;
    msgBox.setText("jmgonzalez");
    msgBox.exec();
}

void MainWindow::onFullScreen()
{
    this->setWindowState(Qt::WindowFullScreen);
}

void MainWindow::onRestoreSize()
{
    this->setWindowState(Qt::WindowNoState);
}


void MainWindow::closeEvent (QCloseEvent *event)
{
    settings->setValue("recientes", recientes);
}

void MainWindow::onOpenRemote()
{
    bool ok;
    QString text = QInputDialog::getText(this, tr("Introduce url a reproducir..."),
                                        tr("Url:"), QLineEdit::Normal,
                                        QDir::home().dirName(), &ok);
    if (ok && !text.isEmpty()) {
        QUrl url(text);
        mediaPlayer_->setMedia(url);
        QAction* action = new QAction(text, this);
        if (mnuRecientes_->actions().size())
            mnuRecientes_->insertAction(mnuRecientes_->actions()[0], action);
        else
            mnuRecientes_->addAction(action);
        recientes.insert(0, text);
        if (mediaPlayer_->isMetaDataAvailable()) {
            QStringList availableMetaData = mediaPlayer_->availableMetaData();
            for (int i = 0; i<availableMetaData.size(); ++i) {
                metaDataList->addItem(availableMetaData.at(i));
            }
        }
        mediaPlayer_->play();
    }
}
