#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSettings>
#include <QStandardItemModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //Setup database
    ConecToDb(db_, "tareas");

    db_.exec("CREATE TABLE IF NOT EXISTS tareas ("
              "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
              "name TEXT,"
              "descripcion TEXT,"
              "date TEXT,"
              "done INTEGER,"
              "id_categ INTEGER"
              ");");

    db_.exec("CREATE TABLE IF NOT EXISTS categorias ("
              "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
              "name TEXT,"
              "descripcion TEXT"
              ");");

    db_.exec("CREATE TABLE IF NOT EXISTS etiquetas ("
              "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
              "name TEXT"
              ");");

    db_.exec("CREATE TABLE IF NOT EXISTS tareas_etiq ("
              "id_tarea INTEGER,"
              "id_etiq INTEGER,"
              "PRIMARY KEY (id_tarea, id_etiq)"
              ");");

    addingTarea_ = false;
    addingCateg_ = false;
    addingEtiq_ = false;

    //Obtenemos las categorias
    QSqlQuery q = db_.exec("SELECT * "
                           "FROM categorias;");

    ui->comboCategoria->addItem("Todas");
    while (q.next()) {
        //Añadimos la categoria al combo y como userData su ID
        ui->comboCategoria->addItem(GetField(q,"name").toString(), GetField(q,"id").toInt());

        //Añadimos la categoria a la tabla de categorias
        int rowNumber = ui->tblCateg->rowCount();
        ui->tblCateg->insertRow(rowNumber);
        QTableWidgetItem* item = new QTableWidgetItem(GetField(q, "name").toString());
        item->setData(Qt::UserRole, GetField(q,"id").toInt());
        ui->tblCateg->setItem(rowNumber, 0, item);
    }
    //Obtenemos las categorias
    q = db_.exec("SELECT * FROM etiquetas;");

    //Activamos el sorting en la tabla de etiquetas
    ui->tblEtiq->setSortingEnabled(true);
    etiquetas_.clear();
    QStringListModel *model = new QStringListModel(this);
    while (q.next()) {
        //Añadimos la categoria al combo y como userData su ID
        model->insertRow(model->rowCount());
        QModelIndex index = model->index(model->rowCount()-1);
        model->setData(index, GetField(q, "name").toString());
        //ui->listEtiquetas-> adaddItem(GetField(q,"name").toString(), GetField(q,"id").toInt());

        //Rellenamos la tabla de etiquetas
        int rowNumber = ui->tblEtiq->rowCount();
        ui->tblEtiq->insertRow(rowNumber);
        QTableWidgetItem* item = new QTableWidgetItem(GetField(q, "name").toString());
        item->setData(Qt::UserRole, GetField(q,"id").toInt());
        ui->tblEtiq->setItem(rowNumber, 0, item);
        etiquetas_[rowNumber] = GetField(q, "id").toInt();
    }
    ui->listEtiquetas->setModel(model);
    ui->listEtiquetas->setSelectionMode(QAbstractItemView::ExtendedSelection);

    setUnifiedTitleAndToolBarOnMac(true);

    connect(ui->actionNuevaCateg, SIGNAL(triggered(bool)), this, SLOT(onAddCategoria()));
    connect(ui->tblCateg, SIGNAL(cellChanged(int,int)), this, SLOT(onCategCellChanged(int, int)));
    connect(ui->actionNuevaEtiq, SIGNAL(triggered(bool)), this, SLOT(onAddEtiq()));
    connect(ui->tblEtiq, SIGNAL(cellChanged(int,int)), this, SLOT(onEtiqCellChanged(int,int)));
    connect(ui->actionNuevaTarea, SIGNAL(triggered()), this, SLOT(onAddTarea()));
    connect(ui->tblTareas, SIGNAL( cellChanged(int,int)), this, SLOT(onTareasCellChanged(int,int)));
    connect(ui->comboCategoria, SIGNAL(currentIndexChanged(int)), this, SLOT(onLoadTareas()));
    connect(ui->listEtiquetas, SIGNAL(clicked(QModelIndex)), this, SLOT(onLoadTareas()));
    onLoadTareas();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onComboChanged()
{
    int row = sender()->property("row").toInt();
    emit onTareasCellChanged(row, 2);
}

QComboBox* MainWindow::createComboCateg(int row)
{
    QComboBox* combo = new QComboBox(this);
    QSqlQuery q = db_.exec("SELECT * "
                           "FROM categorias;");

    while (q.next()) {
        //Añadimos la categoria al combo y como userData su ID
        combo->addItem(GetField(q,"name").toString(), GetField(q,"id").toInt());
        combo->setProperty("row", row);
    }
    connect(combo, SIGNAL(currentIndexChanged(int)), this, SLOT(onComboChanged()));
    return combo;
}

void MainWindow::onAddTarea()
{
    addingTarea_ = true;

    ui->tblTareas->insertRow(ui->tblTareas->rowCount());
    QTableWidgetItem* item = new QTableWidgetItem("");
    item->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
    item->setCheckState(Qt::Unchecked);
    ui->tblTareas->setItem(ui->tblTareas->rowCount()-1, 3, item);

    ui->tblTareas->setItem(ui->tblTareas->rowCount()-1, 0, new QTableWidgetItem(""));
    ui->tblTareas->setItem(ui->tblTareas->rowCount()-1, 1, new QTableWidgetItem(""));

    ui->tblTareas->setCellWidget(ui->tblTareas->rowCount()-1, 2, createComboCateg(ui->tblTareas->rowCount()-1));

    addingTarea_ = false;
}

void MainWindow::onTareasCellChanged(int row, int column)
{
    if (addingTarea_)
        return;

    addingTarea_ = true;

    QString etiquetas = ui->tblTareas->item(row, column)->text();
    QStringList listaEtiquetas = etiquetas.split(" "); // Esta es la lista que vamos a comprobar
    QStringList listaEtiquetasDefinitiva;
    QList<int> listaEtiquetasAGuardar;
    if (column == 4) // Hemos modificado las etiquetas. Comprobamos si existen en la tabla
    {
        bool encontradasTodas = true;
        QSqlQuery q;
        foreach (const QString &str, listaEtiquetas) {
            q = db_.exec(QString("SELECT * from etiquetas WHERE LOWER(NAME) = '%1'").arg(str.toLower()));
            qDebug() << q.lastError().text();
            if (!q.next()) {
                // Una de las etiquetas no existe en la BBDD. No seguimos buscando.
                encontradasTodas = false;
                QMessageBox::warning(this, QCoreApplication::applicationName(),
                                            QString("La etiqueta <b>%1</b> no existe. No se guardará en la tarea.").arg(str),
                                              QMessageBox::Ok);
            } else {
                listaEtiquetasAGuardar.append(GetField(q, "id").toInt());
                listaEtiquetasDefinitiva.append(str);
            }
        }
        ui->tblTareas->setItem(row, column, new QTableWidgetItem(listaEtiquetasDefinitiva.join(" ")));
    }
    int checked = (ui->tblTareas->item(row, 3)->checkState() == Qt::Checked);

    QComboBox *combo = qobject_cast<QComboBox *>(ui->tblTareas->cellWidget(row, 2));
    int idCategoria = combo->currentData(Qt::UserRole).toInt();

    QSqlQuery query;

    int idTarea = -1;
    if (ui->tblTareas->item(row, 0)->data(Qt::UserRole).isNull()) {
        query = db_.exec("INSERT INTO tareas (name, descripcion, date, done, id_categ) "
                 "VALUES ("+QString("'%1','%2','%3','%4','%5');" )\
                 .arg(ui->tblTareas->item(row, 0)->text())\
                 .arg(ui->txtTareaDescr->toPlainText())\
                 .arg(ui->tblTareas->item(row, 1)->text())\
                 .arg(checked)\
                 .arg(idCategoria));
        idTarea = query.lastInsertId().toInt();
        ui->tblTareas->item(row, 0)->setData(Qt::UserRole, idTarea);
    } else {
        idTarea = ui->tblTareas->item(row, 0)->data(Qt::UserRole).toInt();
        query = db_.exec("UPDATE tareas "
                 "SET "+QString("name='%1',descripcion='%2',date='%3',done='%4',id_categ='%5' " )\
                 .arg(ui->tblTareas->item(row, 0)->text())\
                 .arg(ui->txtTareaDescr->toPlainText())\
                 .arg(ui->tblTareas->item(row, 1)->text())\
                 .arg(checked)\
                 .arg(idCategoria) +
                 "WHERE id = " + idTarea + ";");
    }

    // Guardamos las etiquetas de esta categoria (solo si ha cambiado la lista de etiquetas
    if (column==4) {
        foreach (const int &id_etiq, listaEtiquetasAGuardar) {
            QString consulta = QString("INSERT INTO tareas_etiq (id_tarea, id_etiq) \
                                       VALUES ('%1', '%2')").arg(idTarea).arg(id_etiq);
            qDebug() << consulta;
            query = db_.exec(consulta);
            qDebug() << query.lastError().text();
        }
    }

    addingTarea_ = false;
}

void MainWindow::onLoadTareas()
{
    addingTarea_ = true;

    ui->tblTareas->clear();
    ui->tblTareas->setRowCount(0);

    QStringList listaEtiquetasSeleccionadas;
    foreach(const QModelIndex &index, ui->listEtiquetas->selectionModel()->selectedIndexes()) {
        listaEtiquetasSeleccionadas.append(QString::number(etiquetas_[index.row()]));
    }
    QString listaEtiquetas = listaEtiquetasSeleccionadas.join(", ");

    QSqlQuery q, qEtiq;
    if (ui->comboCategoria->currentIndex()>0) {
        //Obtenemos las tareas
        q = db_.exec("SELECT * "
                     "FROM tareas "
                     "WHERE id_categ = " + ui->comboCategoria->currentData().toString());
    } else {
        QString consulta = "SELECT * FROM tareas";
        if (listaEtiquetas!="")
            consulta.append(QString(" WHERE tareas.id IN (SELECT id_tarea FROM tareas_etiq WHERE id_etiq IN (%1))").arg(listaEtiquetas));
        qDebug() << consulta;
        q = db_.exec(consulta);
    }
    while (q.next()) {
        int rowNumber = ui->tblTareas->rowCount();
        int id = GetField(q, "id").toInt();
        ui->tblTareas->insertRow(rowNumber);

        QTableWidgetItem* item = new QTableWidgetItem(GetField(q, "name").toString());
        item->setData(Qt::UserRole, id);
        ui->tblTareas->setItem(rowNumber, 0, item);

        ui->tblTareas->setItem(rowNumber, 1, new QTableWidgetItem(GetField(q, "date").toString()));

        item = new QTableWidgetItem("");
        item->setFlags(Qt::ItemIsUserCheckable | Qt::ItemIsEnabled);
        if (GetField(q, "done").toInt())
            item->setCheckState(Qt::Checked);
        else
            item->setCheckState(Qt::Unchecked);
        ui->tblTareas->setItem(rowNumber, 3, item);

        QComboBox *categ = createComboCateg(rowNumber);
        int idCateg = GetField(q, "id_categ").toInt();
        int index = categ->findData(idCateg);

        categ->setCurrentIndex(index);
        ui->tblTareas->setCellWidget(rowNumber, 2, categ);

        // Cargamos las etiquetas de la tarea
        qEtiq = db_.exec(QString("SELECT name from etiquetas WHERE id IN (SELECT id_etiq FROM tareas_etiq WHERE id_tarea=%1)").arg(id));
        qDebug() << qEtiq.lastError().text();
        QStringList etiq;
        while (qEtiq.next()) {
            etiq.append(GetField(qEtiq, "name").toString());
        }
        ui->tblTareas->setItem(rowNumber, 4, new QTableWidgetItem(etiq.join(" ")));
    }
    //Activamos el sorting en la tabla de categorias
    ui->tblTareas->setSortingEnabled(true);
    addingTarea_ = false;
}

void MainWindow::onAddCategoria()
{
    addingCateg_ = true;

    ui->tblCateg->insertRow(ui->tblCateg->rowCount());
    ui->tblCateg->setItem(ui->tblCateg->rowCount()-1, 0, new QTableWidgetItem(""));
    ui->tblCateg->setItem(ui->tblCateg->rowCount()-1, 1, new QTableWidgetItem(""));


    addingCateg_ = false;
}

void MainWindow::onCategCellChanged(int row, int column)
{
    if (addingCateg_)
        return;

    addingCateg_ = true;

    QSqlQuery query;

    if (ui->tblCateg->item(row, 0)->data(Qt::UserRole).isNull()) {
        query = db_.exec(QString("INSERT INTO categorias (name, descripcion) \
                                VALUES ('%1', '%2');")\
                 .arg(ui->tblCateg->item(row, 0)->text())\
                 .arg(ui->txtTareaDescr->toPlainText()));
        ui->tblCateg->item(row, 0)->setData(Qt::UserRole, query.lastInsertId());
    } else {
        query = db_.exec(QString("UPDATE categorias \
                 SET name='%1',descripcion='%2' \
                 WHERE id = %3 ;")\
                .arg(ui->tblCateg->item(row, 0)->text())\
                .arg(ui->txtTareaDescr->toPlainText())\
                .arg(ui->tblCateg->item(row, 0)->data(Qt::UserRole).toString()));
    }

    addingCateg_ = false;
}

void MainWindow::onAddEtiq()
{
    addingEtiq_ = true;

    ui->tblEtiq->insertRow(ui->tblEtiq->rowCount());
    ui->tblEtiq->setItem(ui->tblEtiq->rowCount()-1, 0, new QTableWidgetItem(""));

    addingEtiq_ = false;
}

void MainWindow::onEtiqCellChanged(int row, int column)
{
    if (addingEtiq_)
        return;

    addingEtiq_ = true;

    QSqlQuery query;

    if (ui->tblEtiq->item(row, 0)->data(Qt::UserRole).isNull()) {
        query = db_.exec(QString("INSERT INTO etiquetas (name) \
                                 VALUES ('%1');")\
                  .arg(ui->tblEtiq->item(row, 0)->text()));
        ui->tblEtiq->item(row, 0)->setData(Qt::UserRole, query.lastInsertId());
    } else {
        query = db_.exec(QString("UPDATE etiquetas \
                 SET name='%1' \
                 WHERE id = %3 ;")\
                .arg(ui->tblEtiq->item(row, 0)->text())\
                .arg(ui->tblEtiq->item(row, 0)->data(Qt::UserRole).toString()));
    }
    etiquetas_[row]=ui->tblEtiq->item(row, 0)->data(Qt::UserRole).toInt();
    addingEtiq_ = false;
}

