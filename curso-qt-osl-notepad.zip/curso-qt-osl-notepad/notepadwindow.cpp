#include "notepadwindow.h"

NotepadWindow::NotepadWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //Establecemos el tamaño inicial de la ventana
    this->setGeometry(30, 30, 800, 600);

    //Establecemos el título de la ventana
    this->setWindowTitle(tr("Super editor de texto"));

    //Inicializamos los menús
    mainMenu_ = new QMenuBar(this);

    mnuArchivo_ = new QMenu(tr("&Archivo"), this);
    mainMenu_->addMenu(mnuArchivo_);

    actArchivoAbrir_ = new QAction(tr("&Abrir"), this);
    actArchivoAbrir_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_O));
    mnuArchivo_->addAction(actArchivoAbrir_);

    actArchivoGuardar_ = new QAction(tr("&Guardar"), this);
    actArchivoGuardar_->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_S));
    mnuArchivo_->addAction(actArchivoGuardar_);

    mnuArchivo_->addSeparator();
    actSalir_ = new QAction(tr("Salir"), this);
    mnuArchivo_->addAction(actSalir_);

    mnuEditar_ = new QMenu(tr("&Editar"), this);
    mainMenu_->addMenu(mnuEditar_);

    actUndo_ = new QAction(tr("Deshacer"), this);
    actUndo_->setShortcut(QKeySequence::Undo);
    mnuEditar_->addAction(actUndo_);

    actRedo_ = new QAction(tr("Rehacer"), this);
    actRedo_->setShortcut(QKeySequence::Redo);
    mnuEditar_->addAction(actRedo_);

    mnuEditar_->addSeparator();

    QToolBar *editToolBar_ = addToolBar(tr("Editar"));

    const QIcon copyIcon = QIcon::fromTheme("edit-copy", QIcon(":/images/copy.png"));
    const QIcon cutIcon = QIcon::fromTheme("edit-cut", QIcon(":/images/cut.png"));
    const QIcon pasteIcon = QIcon::fromTheme("edit-paste", QIcon(":/images/paste.png"));

    actEditarCopiar_ = new QAction(copyIcon, tr("&Copiar"), this);
    actEditarCopiar_->setShortcut(QKeySequence::Copy);
    mnuEditar_->addAction(actEditarCopiar_);

    actEditarPegar_ = new QAction(pasteIcon, tr("&Pegar"), this);
    actEditarPegar_->setShortcut(QKeySequence::Paste);
    mnuEditar_->addAction(actEditarPegar_);

    actEditarCortar_ = new QAction(cutIcon, tr("&Cortar"), this);
    actEditarCortar_->setShortcut(QKeySequence::Cut);
    mnuEditar_->addAction(actEditarCortar_);

    // Añadimos las acciones a la toolbar
    editToolBar_->addAction(actEditarCopiar_);
    editToolBar_->addAction(actEditarCortar_);
    editToolBar_->addAction(actEditarPegar_);

    mnuFormato_ = new QMenu(tr("&Formato"), this);
    mainMenu_->addMenu(mnuFormato_);

    const QIcon boldIcon = QIcon::fromTheme("font-bold", QIcon(":/images/bold.png"));
    const QIcon italicIcon = QIcon::fromTheme("font-italic", QIcon(":/images/italic.png"));
    const QIcon underlineIcon = QIcon::fromTheme("font-underline", QIcon(":/images/underline.png"));

    QAction *actBold_ = new QAction(boldIcon, tr("Negrita"), this);
    mnuFormato_->addAction(actBold_);
    QAction *actItalic_ = new QAction(italicIcon, tr("Cursiva"), this);
    mnuFormato_->addAction(actItalic_);
    QAction *actUnderline_ = new QAction(underlineIcon, tr("Subrayado"), this);
    mnuFormato_->addAction(actUnderline_);


    QToolBar *fontToolbar_ = addToolBar(tr("Fuente"));
    fontToolbar_->addAction(actBold_);
    fontToolbar_->addAction(actItalic_);
    fontToolbar_->addAction(actUnderline_);


    mnuFormato_->addSeparator();
    actFormatoFuente_ = new QAction(tr("&Fuente"), this);
    mnuFormato_->addAction(actFormatoFuente_);

    mnuAyuda_ = new QMenu(tr("Ayuda"));
    actAcercaDe_ = new QAction(tr("Acerca de"), this);
    mnuAyuda_->addAction(actAcercaDe_);
    mainMenu_->addMenu(mnuAyuda_);

    //Agregamos la barra de menú a la ventana
    this->setMenuBar(mainMenu_);

    //Inicializamos el editor de texto
    txtEditor_ = new QTextEdit(this);

    //Conectamos las acciones de los menús con nuestros slots
    connect(actArchivoAbrir_,   SIGNAL(triggered()), this,          SLOT(alAbrir()));
    connect(actArchivoGuardar_, SIGNAL(triggered()), this,          SLOT(alGuardar()));
    connect(actEditarCopiar_,   SIGNAL(triggered()), txtEditor_,    SLOT(copy()));
    connect(actEditarPegar_,    SIGNAL(triggered()), txtEditor_,    SLOT(paste()));
    connect(actFormatoFuente_,  SIGNAL(triggered()), this,          SLOT(alFuente()));

    connect(actSalir_, SIGNAL(triggered()), this, SLOT(onSalir()));
    connect(actEditarCortar_, SIGNAL(triggered()), txtEditor_, SLOT(cut()));
    connect(actUndo_, SIGNAL(triggered()), txtEditor_, SLOT(undo()));
    connect(actRedo_, SIGNAL(triggered()), txtEditor_, SLOT(redo()));

    connect(actAcercaDe_, SIGNAL(triggered()), this, SLOT(onAcercaDe()));

#ifndef QT_NO_CLIPBOARD
    // Des/habilitamos el cortar y copiar
    actEditarCortar_->setEnabled(false);
    actEditarCopiar_->setEnabled(false);
    connect(txtEditor_, &QTextEdit::copyAvailable, actEditarCortar_, &QAction::setEnabled);
    connect(txtEditor_, &QTextEdit::copyAvailable, actEditarCopiar_, &QAction::setEnabled);
#endif // !QT_NO_CLIPBOARD

    connect(txtEditor_, &QTextEdit::undoAvailable, actUndo_, &QAction::setEnabled);
    connect(txtEditor_, &QTextEdit::redoAvailable, actRedo_, &QAction::setEnabled);

    connect(actBold_, SIGNAL(triggered()), this, SLOT(onBold()));
    connect(actItalic_, SIGNAL(triggered()), this, SLOT(onItalic()));
    connect(actUnderline_, SIGNAL(triggered()), this, SLOT(onUnderline()));


    //Agregamos el editor de texto a la ventana
    this->setCentralWidget(txtEditor_);
}

NotepadWindow::~NotepadWindow()
{
    //Liberamos los recursos
    mainMenu_->deleteLater();
    actArchivoAbrir_->deleteLater();
    actArchivoGuardar_->deleteLater();
    mnuArchivo_->deleteLater();
    actEditarCopiar_->deleteLater();
    actEditarPegar_->deleteLater();
    mnuEditar_->deleteLater();
    actFormatoFuente_->deleteLater();
    mnuFormato_->deleteLater();
    txtEditor_->deleteLater();
}

void NotepadWindow::alAbrir()
{
    //Mostramos un dialogo de apertura de ficheros y almacenamos la selección (ruta) en una variable
    QString nombreArchivo;
    //qDebug() << QStandardPaths::displayName(QStandardPaths::DownloadLocation);
    nombreArchivo = QFileDialog::getOpenFileName(this,
                                                 tr("Abrir archivo de texto plano"),
                                                 QStandardPaths::displayName(QStandardPaths::DownloadLocation),
                                                 tr("Archivos de texto plano (*.txt)"));
    if (nombreArchivo != "") {
        //Intentamos abrir el archivo
        QFile archivo;
        archivo.setFileName(nombreArchivo);
        if (archivo.open(QFile::ReadOnly)) {
            //Si se pudo abrir el archivo, lo leemos y colocamos su contenido en nuestro editor
            //txtEditor_->setPlainText(archivo.readAll());
            txtEditor_->setHtml(archivo.readAll());
            //Se cierra el fichero
            archivo.close();
        }
    }
}

void NotepadWindow::alGuardar()
{
    //Mostramos un dialogo de guardado de ficheros y almacenamos la selección (ruta) en una variable
    QString nombreArchivo;
    nombreArchivo = QFileDialog::getSaveFileName(this,
                                                 tr("Guardar archivo de texto plano"),
                                                 QStandardPaths::displayName(QStandardPaths::DownloadLocation),
                                                 tr("Archivos de texto plano (*.txt)"));
    if (nombreArchivo != "") {
        //Intentamos abrir el archivo
        QFile archivo;
        archivo.setFileName(nombreArchivo + ".txt");
        if (archivo.open(QFile::WriteOnly | QFile::Truncate)) {
            //Si se pudo abrir el archivo, escribimos el contenido del editor
            archivo.write(txtEditor_->toHtml().toUtf8());
            //Se cierra el fichero
            archivo.close();
        }
    }
}

void NotepadWindow::alFuente()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, txtEditor_->font(), this);
    if (ok) {
        // Si el usuario hizo click en OK, se establece la fuente seleccionada
        QTextCursor cursor=txtEditor_->textCursor();

        if (!cursor.hasSelection()) {
            cursor.movePosition(QTextCursor::StartOfWord);
            cursor.movePosition(QTextCursor::EndOfWord, QTextCursor::KeepAnchor);
        }

        QTextCharFormat format;
        format.setFont(font);

        cursor.mergeCharFormat(format);
    }
}


void NotepadWindow::onSalir()
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, windowTitle(),
                                                                    tr("Seguro que quieres salir?\n"),
                                                                    QMessageBox::Cancel | QMessageBox::No | QMessageBox::Yes,
                                                                    QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes)
        QCoreApplication::quit();
}

void NotepadWindow::closeEvent (QCloseEvent *e)
{
    // Atajo para evitar problema en Mac que si salimos con Cmd+Q llama a este evento dos veces
    static bool already_closed = false;
    if (!already_closed) {
        switch(QMessageBox(QMessageBox::Question, windowTitle(), "Seguro que quieres salir?", QMessageBox::Yes|QMessageBox::Cancel, this).exec()) {
        case QMessageBox::Yes:
            already_closed = true;
            e->accept();
            break;
        default:
            e->ignore();
        }
    }
}

void NotepadWindow::onAcercaDe()
{
    QMessageBox msgBox;
    msgBox.setText("jmgonzalez");
    msgBox.exec();
}

void NotepadWindow::onBold()
{
    QTextCursor cursor=txtEditor_->textCursor();

    if (!cursor.hasSelection()) {
        cursor.movePosition(QTextCursor::StartOfWord);
        cursor.movePosition(QTextCursor::EndOfWord, QTextCursor::KeepAnchor);
    }

    QTextCharFormat format;
    if (cursor.charFormat().fontWeight() == QFont::Bold)
        format.setFontWeight(QFont::Normal);
    else
        format.setFontWeight(QFont::Bold);

    cursor.mergeCharFormat(format);
}

void NotepadWindow::onItalic()
{
    QTextCursor cursor=txtEditor_->textCursor();

    if (!cursor.hasSelection()) {
        cursor.movePosition(QTextCursor::StartOfWord);
        cursor.movePosition(QTextCursor::EndOfWord, QTextCursor::KeepAnchor);
    }

    QTextCharFormat format;
    format.setFontItalic(!cursor.charFormat().fontItalic());

    cursor.mergeCharFormat(format);
}

void NotepadWindow::onUnderline()
{
    QTextCursor cursor=txtEditor_->textCursor();

    if (!cursor.hasSelection()) {
        cursor.movePosition(QTextCursor::StartOfWord);
        cursor.movePosition(QTextCursor::EndOfWord, QTextCursor::KeepAnchor);
    }

    QTextCharFormat format;
    format.setFontUnderline(!(cursor.charFormat().fontUnderline()));

    cursor.mergeCharFormat(format);
}

