#ifndef NOTEPADWINDOW_H
#define NOTEPADWINDOW_H

#include <QMainWindow>
//Incluimos librerias necesarias
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QTextEdit>
#include <QFileDialog>
#include <QFile>
#include <QFontDialog>
#include <QClipboard>
#include <QKeySequence>

#include <QStandardPaths>
#include <QCoreApplication>
#include <QMessageBox>
#include <QToolBar>
#include <QCloseEvent>
#include <QFont>

class NotepadWindow : public QMainWindow
{
    Q_OBJECT

public:
    NotepadWindow(QWidget *parent = 0);
    ~NotepadWindow();

    void closeEvent (QCloseEvent *event);

    enum formatFontType { Bold, Italic, Underline, Font };

private slots:
    void alAbrir();
    void alGuardar();
    void alFuente();
    void onSalir();
    void onAcercaDe();
    void onBold();
    void onItalic();
    void onUnderline();

private:
    QMenuBar*       mainMenu_;
    QMenu*          mnuArchivo_;
    QAction*        actArchivoAbrir_;
    QAction*        actArchivoGuardar_;
    QAction*        actSalir_;
    QMenu*          mnuFormato_;
    QAction*        actFormatoFuente_;
    QMenu*          mnuEditar_;
    QAction*        actEditarCopiar_;
    QAction*        actEditarPegar_;
    QAction*        actEditarCortar_;
    QAction*        actUndo_;
    QAction*        actRedo_;
    QTextEdit* txtEditor_;
    QClipboard *    portapapeles_;
    QMenu*          mnuAyuda_;
    QAction*        actAcercaDe_;
    QToolBar*       editToolbar_;
    QToolBar*       fontToolbar_;

};

#endif // NOTEPADWINDOW_H
