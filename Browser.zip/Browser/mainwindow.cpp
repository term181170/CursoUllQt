#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mywebpage.h"

#include <QCommandLinkButton>
#include <QDesktopWidget>
#include <QLabel>
#include <QProgressBar>
#include <QTextEdit>
#include <QToolButton>
#include <QToolbar>
#include <QWebEngineView>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Mi navegador");
    QDesktopWidget dw;
    setFixedSize(dw.width()*0.7, dw.height()*0.7);
    int x = (dw.width() - size().width()) / 2;
    int y = (dw.height() - size().height()) / 2;
    //y -= 50;
    move(x, y);

    webView = new QWebEngineView(this);
    webView->setPage(new MyWebPage());
    QToolBar *bar = addToolBar("url");
    bar->setMaximumHeight(30);
    edUrl = new QLineEdit("www.google.es");
    QToolButton *goButton = new QToolButton();
    QAction *actGo = new QAction(QIcon(":/images/go.png"), "Ir", this);
    goButton->setDefaultAction(actGo);
    bar->addAction(webView->pageAction(QWebEnginePage::Back));
    bar->addAction(webView->pageAction(QWebEnginePage::Forward));
    bar->addAction(webView->pageAction(QWebEnginePage::Reload));
    bar->addAction(webView->pageAction(QWebEnginePage::Stop));
    bar->addWidget(edUrl);
    bar->addWidget(goButton);
    setCentralWidget(webView);

    connect(actGo, SIGNAL(triggered(bool)), this, SLOT(toGoUrl()));
    connect(edUrl, SIGNAL(returnPressed()), this, SLOT(toGoUrl()));
    connect(webView, SIGNAL(loadStarted()), this, SLOT(onLoadStarted()));
    connect(webView, SIGNAL(loadFinished(bool)), this, SLOT(onLoadFinished()));
    connect(webView, SIGNAL(loadProgress(int)), this, SLOT(onProgress(int)));
    connect(webView->page(), SIGNAL(linkClicked(QUrl)), this, SLOT(onLinkClicked(QUrl)));
    createStatusBar();

#if defined(Q_OS_OSX)
    QApplication::setQuitOnLastWindowClosed(false);
#else
    QApplication::setQuitOnLastWindowClosed(true);
#endif

    toGoUrl();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::toGoUrl()
{
    webView->load(QUrl::fromUserInput(edUrl->text()));
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("Listo"));
}

void MainWindow::onLoadStarted()
{
    statusBar()->clearMessage();
    progressBar = new QProgressBar(this);
    statusBar()->addWidget(progressBar, 100);
}

void MainWindow::onLoadFinished()
{
    //free(progressBar);
    statusBar()->removeWidget(progressBar);
    progressBar=0;
    statusBar()->showMessage(tr("Listo"));
}

void MainWindow::onProgress(int progress)
{
    if (progressBar) {
        progressBar->setValue(progress);
    }
}

void MainWindow::onLinkClicked(const QUrl & url)
{
    qDebug() << url;
}
