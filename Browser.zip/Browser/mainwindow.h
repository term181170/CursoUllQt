#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWebEngineView>
#include <QLineEdit>
#include <QProgressBar>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void toGoUrl();
    void onLoadStarted();
    void onLoadFinished();
    void onProgress(int progress);
    void onLinkClicked(const QUrl &url);
private:
    Ui::MainWindow *ui;
    QWebEngineView *webView;
    QLineEdit *edUrl;
    void createStatusBar();
    QProgressBar *progressBar;
};

#endif // MAINWINDOW_H
